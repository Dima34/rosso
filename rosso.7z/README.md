# Rosso

## Type `npm install` to install the packages
## Type `gulp watch` to start working


